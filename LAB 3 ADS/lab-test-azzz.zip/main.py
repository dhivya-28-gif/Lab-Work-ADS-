def display_menu():
        print("Menu")
        print("------")
        print("1 - Display List")
        print("2 - Add an item to List")
        print("3 - Delete an item from List")
        print("0 - Exit")
        print()
   
my_list = [] 


def display_list():
    print(f"List = {my_list}")

def add_list():
    add = int(input("Type the item that to be added >"))
    my_list.append(add)
    
def delete_item():
    delete = int(input("Type the item to be deleted >"))
    my_list.remove(delete)
            
while True:
    print()
    display_menu()
    choice = int(input("Your option >"))
    if choice == 1:
        print("=" * 12)
        print("Display List")
        print("=" * 12)
        print()
        display_list()
    elif choice == 2:
        print("=" * 12)
        print("Add Item")
        print("=" * 12)
        print()
        display_list()
    elif choice == 3:
        print("=" * 12)
        print("Delete Item")
        print("=" * 12)
        print()
        display_list()
        
    else:
        print("Please select a valid option")
                

if __name__ == "__main__":
    main()
                
                
                
                
                
                
                    
                    
    
        
        
        
        
        
        
        
        
        
        
        
                
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
